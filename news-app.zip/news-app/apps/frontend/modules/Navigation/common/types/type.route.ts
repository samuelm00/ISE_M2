import { RoutePath } from '../constants/constant.route';

export interface Route {
  label: string;
  href: RoutePath;
}
